const products = [
  {
    name: "Blue T-Shirt",
    price: 499,
    image: "https://via.placeholder.com/200x200?text=T-Shirt"
  },
  {
    name: "Running Shoes",
    price: 1299,
    image: "https://via.placeholder.com/200x200?text=Shoes"
  },
  {
    name: "Smart Watch",
    price: 2999,
    image: "https://via.placeholder.com/200x200?text=Watch"
  }
];

const productList = document.getElementById("product-list");

products.forEach(product => {
  const productCard = document.createElement("div");
  productCard.classList.add("product");

  productCard.innerHTML = `
    <img src="${product.image}" alt="${product.name}">
    <h2>${product.name}</h2>
    <p>₹${product.price}</p>
    <button>Add to Cart</button>
  `;

  productList.appendChild(productCard);
});
